xaxis=1:1:255
for n=2:1:256
    ccr(n-1)=mean(x(n,:).*x(n-1,:))
end 

k=1:1:255
figure(100)
plot(xaxis,ccr,k,k-1), title(" cross corr x(n,n-1)"),xlabel('n')
