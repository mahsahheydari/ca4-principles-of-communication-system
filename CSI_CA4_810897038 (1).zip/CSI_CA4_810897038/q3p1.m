Xmatrix = randn(256,256);
for i=1:1:256
meow(i) = mean(Xmatrix(i,:));
mean_coltimeXmatrix(i) = mean(Xmatrix(:,i));
end

figure(922)
plot(meow);
title('mu x[n]');
xlabel('n');
ylabel('Mean');

figure(793)
plot(mean_coltimeXmatrix);
title('x[k]');
xlabel('k');
ylabel('time Mean');
w=meow
p=mean_coltimeXmatrix
