a=[ 1,2 ; 3, 3; 4,4]
meancolumns_a = mean(transpose(a))