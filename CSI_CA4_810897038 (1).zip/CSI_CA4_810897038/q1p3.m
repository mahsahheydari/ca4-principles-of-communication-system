D1 = randn([1 2000]);
D2 = randn([1 2000]);
cnt=zeros(2000,1);
for i=1:2000
    if D1(i)<0.6 && D1(i)>0.4
        cnt(i)=1;
    end
end
L=length(cnt);
D3=0;
for i=1:L
    if cnt(i)
        D3=[D3,D2(i)];
    end
end
D3=D3(2:end);
histogram(D3,100), title("gaussian")



        