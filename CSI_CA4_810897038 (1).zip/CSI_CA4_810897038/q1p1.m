X = randn([1 2000]);
u = rand(2000,1)

histogram(X,150), title("gaussian")
figure
histogram(u,150), title("uniform")


