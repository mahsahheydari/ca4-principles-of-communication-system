an=-0.7;
Zn=a1*X+Y*sqrt(1-(an)^2);
cntnn=zeros(2000,1);
cnntn1=zeros(2000,1);
for i=1:2000
    if Zn(i)<0.6 && Zn(i)>0.4
        cntnn(i)=1;
   end
   if  Zn(i)<-0.4 && Zn(i)>-0.6
        cnntn1(i)=1;
    end
end
L=length(cntnn);
L1=length(cnntn1);
Dnn3=0;
Dnn3_1=0;
for i=1:L1
    if cnntn1(i)
        Dnn3_1=[Dnn3_1,X(i)];
    end
end
for i=1:L
    if cntnn(i)
        Dnn3=[Dnn3,X(i)];
    end
end
Dnn3=Dnn3(2:end);
Dnn3_1=Dnn3_1(2:end);
subplot(2,1,1)
histogram(Dnn3,100), title("0.5 and alpha = -0.7")
subplot(2,1,2)
histogram(Dnn3_1,100),title("-05 and alpha=-0.7")