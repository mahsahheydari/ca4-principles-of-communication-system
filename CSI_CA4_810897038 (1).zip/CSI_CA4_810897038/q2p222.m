anN=-0.7;
ZnN1=a1*X+Y*sqrt(1-(anN)^2);
cntnnN=zeros(2000,1);
for i=1:2000
    if ZnN1(i)<-0.4 && ZnN1(i)>-0.6
        cntnnN(i)=1;
    end
end
L=length(cntnnN);
DnnN3=0;
for i=1:L
    if cntnnN(i)
        DnnN3=[DnnN3,ZnN1(i)];
    end
end
DnnN3=DnnN3(2:end);
histogram(DnnN3,100),title("Z=-0.5 ALPHA�=-0.7")