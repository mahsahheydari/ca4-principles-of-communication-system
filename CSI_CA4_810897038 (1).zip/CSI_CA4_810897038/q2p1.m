X = randn([1 2000]);
Y = randn([1 2000]);
x=-4:0.001:4
y=-4:0.001:4
a1=0.5;
Z1=a1*X+Y*sqrt(1-(a1)^2);
a2=-0.5;
Z2=a2*X+Y*sqrt(1-(a2)^2);
a3=0.9;
Z3=a3*X+Y*sqrt(1-(a3)^2);
a4=-0.9;
Z4=a4*X+Y*sqrt(1-(a4)^2);
% [r1,xlags4] = xcorr(X,Z1);
% [r2,xlags4] = xcorr(X,Z2);
% [r3,xlags4] = xcorr(X,Z3);
% [r4,xlags4] = xcorr(X,Z4);
subplot(2,4,1)

plot(X,Z1,'.',x,y),title('alpha=0.5') 

subplot(2,4,2)

plot(X,Z2,'.',x,y),title('alpha=-0.5') 
subplot(2,4,3)
plot(X,Z3,'.',x,y), title('alpha=0.9')
subplot(2,4,4)

plot(X,Z4,'.',x,y) ,title('alpha=-0.9')
subplot(2,4,5)
histogram(Z1,600)
subplot(2,4,6)
histogram(Z2,600)
subplot(2,4,7)
histogram(Z3,600)
subplot(2,4,8)
histogram(Z4,600)


