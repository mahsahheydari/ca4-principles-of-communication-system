an=0.7;
Zn=a1*X+Y*sqrt(1-(an)^2);
cntn=zeros(2000,1);
cntn1=zeros(2000,1);
for i=1:2000
    if Zn(i)<0.6 && Zn(i)>0.4
        cntn(i)=1;
   end
   if  Zn(i)<-0.4 && Zn(i)>-0.6
        cntn1(i)=1;
    end
end
L=length(cntn);
L1=length(cntn1);
Dn3=0;
Dn3_1=0;
for i=1:L1
    if cntn1(i)
        Dn3_1=[Dn3_1,X(i)];
    end
end
for i=1:L
    if cntn(i)
        Dn3=[Dn3,X(i)];
    end
end
Dn3=Dn3(2:end);
Dn3_1=Dn3_1(2:end);
subplot(2,1,1)
histogram(Dn3,100),title("0.5 and alpha = 0.7")
subplot(2,1,2)
histogram(Dn3_1,100),title("-0.5 and alpha = 0.7")