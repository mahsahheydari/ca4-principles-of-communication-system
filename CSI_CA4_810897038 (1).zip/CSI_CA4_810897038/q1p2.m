X1 = randn([1 2000]);
X2 = randn([1 2000]);
UNF1 = -sqrt(3) + (2*sqrt(3))*rand(2000,1);
UNF2 = -sqrt(3) + (2*sqrt(3))*rand(2000,1);
figure(329)
plot(X1,X2,"."), title("joint distribution of gaussian")
figure(12)
plot(UNF1,UNF2,"."), title("joint distribution of Uniform")
figure(101)
plot(X1,UNF1,"."), title("joint distribution of gaussian and Uniform")

