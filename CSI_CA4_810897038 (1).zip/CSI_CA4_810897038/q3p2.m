n1= 4;
n2= 6;
x=-4:0.001:4
y=-4:0.001:4
% [matcor,xlags4] = xcorr(Xmatrix(n1,:),Xmatrix(n2,:));

figure(209)
plot(Xmatrix(n1,:),Xmatrix(n2,:),'.',x,y) 
