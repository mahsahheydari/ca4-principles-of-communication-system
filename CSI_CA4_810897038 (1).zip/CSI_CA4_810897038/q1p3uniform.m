%uniform
UN1 = -sqrt(3) + (2*sqrt(3))*rand(2000,1);
UN2 = -sqrt(3) + (2*sqrt(3))*rand(2000,1);
cntu=zeros(2000,1);
for i=1:2000
    if UN1(i)<0.6 && UN1(i)>0.4
        cntu(i)=1;
    end
end
L=length(cntu);
UN3=0;
for i=1:L
    if cntu(i)
        UN3=[UN3,UN2(i)];
    end
end
UN3=UN3(2:end);
histogram(UN3,100),title("uniform")